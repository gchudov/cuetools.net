#pragma once

namespace APE
{

uint32 CRC_update(uint32 crc, const unsigned char * pData, int nBytes);

}
