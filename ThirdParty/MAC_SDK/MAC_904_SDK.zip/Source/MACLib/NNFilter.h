#pragma once

#include "All.h"

namespace APE
{

#include "RollBuffer.h"
class IPredictorDecompress;

#pragma pack(push, 1)

/**************************************************************************************************
CNNFilter
**************************************************************************************************/
template <class INTTYPE> class CNNFilter
{
public:
    CNNFilter(int nOrder, int nShift, int nVersion = -1);
    virtual ~CNNFilter();

    INTTYPE Compress(INTTYPE nInput);
    INTTYPE Decompress(INTTYPE nInput);
    void Flush();

    void SetInterimMode(bool bInterimMode) { m_bInterimMode = bInterimMode; }

private:
    bool useAVX2() const { return m_bAVX2Available; }

    __forceinline short GetSaturatedShortFromInt(INTTYPE nValue) const
    {
        short sValue = static_cast<short>(nValue);
        if (sValue != nValue)
            sValue = (nValue >> (8 * sizeof(INTTYPE) - 1)) ^ 0x7FFF;
        return sValue;
    }

    int m_nOrder;
    int m_nShift;
    int m_nOneShiftedByShift;
    int m_nVersion;
    short * m_paryM16;
    int * m_paryM32;
    APE::CRollBuffer<short> m_rbInput16;
    APE::CRollBuffer<short> m_rbDeltaM16;
    APE::CRollBuffer<int> m_rbInput32;
    APE::CRollBuffer<int> m_rbDeltaM32;
    bool m_bInterimMode;
    bool m_bAVX2Available;
    INTTYPE m_nRunningAverage;
};

// forward declare the CNNFilter classes because it helps with a Clang warning
#ifdef _MSC_VER
extern template class CNNFilter<int>;
extern template class CNNFilter<int64>;
#endif

#pragma pack(pop)

}
