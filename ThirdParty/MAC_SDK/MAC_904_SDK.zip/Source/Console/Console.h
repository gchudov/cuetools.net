#pragma once

#include "All.h"

// functions
int Tag(const TCHAR * pFilename, const TCHAR * pTagString);
TCHAR * GetParameterFromList(LPCTSTR pList, LPCTSTR pDelimiter, int nCount);
int RemoveTags(const TCHAR * pFilename);
#ifndef PLATFORM_WINDOWS
int main(int argc, char * argv[]);
#else
int _tmain(int argc, TCHAR * argv[]);
#endif

// globals
extern TICK_COUNT_TYPE g_nInitialTickCount;
