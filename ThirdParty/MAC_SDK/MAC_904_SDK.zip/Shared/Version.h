#pragma once

/* build batch file */
/*
#ifdef APE_BATCH_FILE_VERSION
Set _MA=904
Set _MAV=9.04
#endif
*/

/* major version number */
#define MAC_VERSION_MAJOR 9

/* build version number */
#define MAC_VERSION_REVISION 04

/* leave this so the end of file doesn't get truncated */
