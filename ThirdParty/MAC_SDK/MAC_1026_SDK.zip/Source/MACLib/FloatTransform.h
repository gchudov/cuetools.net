#pragma once

namespace APE
{

/**************************************************************************************************
Float transforms
**************************************************************************************************/
class CFloatTransform
{
public:
    static void Process(uint32 * pBuffer, int64 nSamples);
};

}
