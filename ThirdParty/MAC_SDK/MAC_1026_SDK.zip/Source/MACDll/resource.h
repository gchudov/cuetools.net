//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MACDll.rc
//
#define IDD_WAV_INFO                    101
#define IDD_APE_INFO                    103
#define IDB_BITMAP1                     104
#define IDI_MONKEY_LEFT                 105
#define IDI_MONKEY_RIGHT                106
#define IDD_WINAMP_SETTINGS             107
#define IDD_COMPRESSION                 108
#define IDC_R1                          1000
#define IDC_R3                          1001
#define IDC_R2                          1002
#define IDC_R4                          1003
#define IDC_R5                          1004
#define CANCEL_BUTTON                   1011
#define THREAD_PRIORITY_SLIDER          1014
#define FILE_DISPLAY_METHOD_EDIT        1028
#define SCALE_OUTPUT_CHECK              1031
#define IGNORE_BITSTREAM_ERRORS_CHECK   1034
#define SUPPRESS_SILENCE_CHECK          1035

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
